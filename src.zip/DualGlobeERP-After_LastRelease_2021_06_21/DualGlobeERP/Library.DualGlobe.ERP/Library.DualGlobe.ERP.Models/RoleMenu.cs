using System;
using System.Runtime.CompilerServices;

namespace Library.DualGlobe.ERP.Models
{
	public class RoleMenu
	{
		public DateTime createDate
		{
			get;
			set;
		}

		public int Id
		{
			get;
			set;
		}

		public int MenuId
		{
			get;
			set;
		}

		public int RoleId
		{
			get;
			set;
		}

		public RoleMenu()
		{
		}
	}
}