using System;
using System.Runtime.CompilerServices;

namespace Library.DualGlobe.ERP.Models
{
	public class WorkPermitAddress
	{
		public string Address
		{
			get;
			set;
		}

		public int Id
		{
			get;
			set;
		}

		public WorkPermitAddress()
		{
		}
	}
}